# AnimeTown.Fun

A free anime watching website

## Contributors

[Sohom829](https://github.com/Sohom829)

[Shaxpartan](https://github.com/Shaxpartan)

[Alpha](https://github.com/Alpha5959)
