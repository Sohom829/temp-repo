module.exports = {
  gogoanime_url: "https://gogoanime.lu/", //gogoanime's website url
  port: 6969, //Port for website.
};
