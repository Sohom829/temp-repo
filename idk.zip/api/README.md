# AnimeTown.Fun API

An API for AnimeTown.Fun website
