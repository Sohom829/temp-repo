module.exports = {
  api_url: "http://localhost:6969",
  // Enter your api host's url or if hosting locally/on your own computer use https://localhost:6969

  time_update: "200",
  // Enter Seconds for updating recently added and popular list. For disabling it Enter disable

  port: "8000",
  // Enter port for your website
};
